<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

/** Satu koneksi PDO per request. Semua query WAJIB prepared statement (NFR-SEC-04). */
final class Database
{
    private static ?PDO $pdo = null;

    public static function connection(): PDO
    {
        if (self::$pdo === null) {
            $c = Config::get('database');
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                $c['host'], $c['port'], $c['name'], $c['charset']
            );
            self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                // timestamp di skema memakai UTC (si_kesa_v9.sql: time_zone +00:00).
                // sql_mode ketat: nilai tidak valid (enum di luar daftar, angka/teks melebihi kolom) DITOLAK database,
                // bukan dipotong diam-diam. Bawaan my.ini XAMPP tidak ketat (hasil tests/Database/uji_skema.php).
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+00:00', sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION'",
            ]);
        }
        return self::$pdo;
    }

    /**
     * Jalankan $fn dalam satu transaksi: semua berhasil (commit) atau semua dibatalkan (rollback).
     * Exception dilempar ulang agar tetap diproses ErrorHandler.
     */
    public static function transaksi(callable $fn): mixed
    {
        $pdo = self::connection();
        $pdo->beginTransaction();
        try {
            $hasil = $fn($pdo);
            $pdo->commit();
            return $hasil;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }
}
